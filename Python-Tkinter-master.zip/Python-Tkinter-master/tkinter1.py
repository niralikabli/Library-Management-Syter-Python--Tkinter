from Tkinter import *

root = Tk() #Tk() is a constructor of tkinter class, root = a blank window

theLabel = Label(root,text = "Hi Sona!!!") #Puts text in the black window

theLabel.pack() #pack it in window so to see it

root.mainloop() #puts in loop so window continuously display until u press close



